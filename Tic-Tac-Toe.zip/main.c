/*
  Cameron Mesman
  cmesman@iastate.edu
  CPRE 185 Section 6
  Programming Practice 2
  Reflection 1: What were you trying to achieve?
    In this program, I was trying to create a tic tac toe game that could be played between two users. It would allow each player to alternate turns, placing their x or o in the desired location until someone got 3 in a row or the board was filled.
  Reflection 2: Were you successful? Why or Why not?
    I believe that I was successful. My program allows both players to play and checks for a win. I also implimented a feature to check if the user's input was valid.
  Reflection 3: Would you do anything differently if starting this over?
    If I started this program over, I would probably plan it out a bit more in advance. My lack of planning led to some avoidable errors.
  Reflection 4: What was the most important thing you learned while writing this code
    The most important thing I learned was how to manipulate 2D arrays esspecially by passing them to other functions.
*/
#include <stdio.h>

#define ARR_SIZE 3

// prototypes
void printBoard(char board[ARR_SIZE][ARR_SIZE]);
void checkAnswer(int* answer, char board[ARR_SIZE][ARR_SIZE]);
int checkWin(char board[ARR_SIZE][ARR_SIZE]);
int checkTie(char board[ARR_SIZE][ARR_SIZE]);


int main(void) {
  int player1, player2;
  int tie = 0;

  // initializes board
  char board[3][3] = {
    {'_', '_','_'},
    {'_', '_', '_'},
    {'_', '_', '_'}
    };

  while(1) {
    printBoard(board);
    printf("Player 1, enter a number to place your x at that spot: ");
    scanf("%d", &player1);
    // checks to make sure input is valid
    checkAnswer(&player1, board);
    // places marker at correct array index based on user input
    board[(player1-1) / ARR_SIZE][(player1-1) % ARR_SIZE] = 'x';
    if (checkWin(board)) {
      printBoard(board);
      printf("Player 1 won!");
      return 0;
    }
    if (checkTie(board)) {
      printBoard(board);
      printf("It's a tie!");
      return 0;
    }

    printBoard(board);
    printf("Player 2, enter a number to place your o at that spot: ");
    scanf("%d", &player2);
    // checks to make sure input is valid
    checkAnswer(&player2, board);
    // places marker at correct array index based on user input
    board[(player2-1) / ARR_SIZE][(player2-1) % ARR_SIZE] = 'o';
    if (checkWin(board)) {
      printBoard(board);
      printf("Player 2 won!");
      return 0;
    }
  }

  return 0;
}

void printBoard(char board[ARR_SIZE][ARR_SIZE]) {

  // prints template
  printf("\nTemplate\n1  2  3\n4  5  6\n7  8  9\n\n");

  // prints current board state
  for (int i = 0; i < ARR_SIZE; i++) {
    for (int j = 0; j < ARR_SIZE; j++) {
      printf("%c  ", board[i][j]);
    }
    printf("\n");
  }
}

void checkAnswer(int* answer, char board[ARR_SIZE][ARR_SIZE]) {
  while (*answer < 1 || *answer > 9 || board[(*answer-1) / ARR_SIZE][(*answer-1) % ARR_SIZE] != '_') {
    printf("That is not a valid input or that spot is taken. Please try again: ");
    scanf("%d", answer);
  }
}

int checkWin(char board[ARR_SIZE][ARR_SIZE]) {
  int xCounter;
  int oCounter;

  // checks for a horizontal win
  for (int i = 0; i < ARR_SIZE; i++) {
    xCounter = 0;
    oCounter = 0;
    for (int j = 0; j < ARR_SIZE; j++) {
      if (board[i][j] == 'x') {
        xCounter++;
      }
      else if (board[i][j] == 'o') {
        oCounter++;
      }
    }
    if (xCounter == 3 || oCounter == 3) {
      return 1;
    }
  }

  // checks for a vertical win
  for (int i = 0; i < ARR_SIZE; i++) {
    xCounter = 0;
    oCounter = 0;
    for (int j = 0; j < ARR_SIZE; j++) {
      if (board[j][i] == 'x') {
        xCounter++;
      }
      else if (board[j][i] == 'o') {
        oCounter++;
      }
    }
    if (xCounter == 3 || oCounter == 3) {
      return 1;
    }
  }

  // checks for a diagonal left to right win
  xCounter = 0;
  oCounter = 0;
  for (int i = 0; i < ARR_SIZE; i++) {
    if (board[i][i] == 'x') {
      xCounter++;
    }
    else if (board[i][i] == 'o') {
      oCounter++;
    }
  }
  if (xCounter == 3 || oCounter == 3) {
    return 1;
  }

  // checks for a diagonal right to left win
  xCounter = 0;
  oCounter = 0;
  int j = 2;
  for (int i = 0; i < ARR_SIZE; i++) {
    if (board[i][j] == 'x') {
      xCounter++;
    }
    else if (board[i][j] == 'o') {
      oCounter++;
    }
    j--;
  }
  if (xCounter == 3 || oCounter == 3) {
    return 1;
  }
  return 0;
}

int checkTie(char board[ARR_SIZE][ARR_SIZE]) {
  int counter = 0;
  for (int i = 0; i < ARR_SIZE; i++) {
    for (int j = 0; j < ARR_SIZE; j++) {
      if (board[i][j] != '_') {
        counter++;
      }
    }
  }
  if (counter == 9) {
    return 1;
  }
  else {
    return 0;
  }
}