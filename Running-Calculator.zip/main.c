#include <stdio.h>

// Prototypes
double CalcPace(int time, double distance);
int CalcTime(int pace, double distance);
double CalcDistance(int pace, int time);

int main(void) {
  int time = 0;
  int pace = 0;
  double distance = 0;
  int paceMinutes = 0;
  int paceSeconds = 0;
  int hours = 0;
  int minutes = 0;
  int seconds = 0;

  // user's choice for wha they want to calculate
  char calcType;

  // asks user wha they want to calculate
  printf("Enter \"p\" to calculate pace. Enter \"t\" to calculate time. Enter \"d\" to calculate distance.\nEnter here: ");
  scanf("%c", &calcType);

  while(calcType != 'p' && calcType != 't' && calcType != 'd') {
    printf("That is not a valid input. Please try again: ");
    scanf(" %c", &calcType);
  }

  // determines what the user inputted
  if(calcType == 'p') {
    pace = CalcPace(time, distance);

    paceMinutes = pace / 60;
    paceSeconds = pace % 60;
    if (paceSeconds > 9) {
      printf("\nPace: %d:%d per mile.\n", paceMinutes, paceSeconds);
    }
    else {
      printf("\nPace: %d:0%d per mile.\n", paceMinutes, paceSeconds);
    }
  }
  else if(calcType == 't') {
    time = CalcTime(pace, distance);

    hours = time / 3600;
    minutes = (time % 3600) / 60;
    seconds = (time % 3600) % 60;

    if (minutes < 10) {
      if (hours == 0) {
        printf("\nTime: 0%d:%d", minutes, seconds);
      }
      else {
        printf("\nTime: %d:0%d:%d", hours, minutes, seconds);
      }
    }
    if (seconds < 10) {
      if (hours == 0) {
        printf("\nTime: %d:0%d", minutes, seconds);
      }
      else {
        printf("\nTime: %d:%d:0%d", hours, minutes, seconds);
      }
    }
    if (seconds > 10 && minutes > 10) {
      if (hours == 0) {
        printf("\nTime: %d:%d", minutes, seconds);
      }
      else {
        printf("\nTime: %d:%d:%d", hours, minutes, seconds);
      }
    }
  }
  else if(calcType == 'd') {
    distance = CalcDistance(pace, time);

    printf("\nDistance: %.2lf", distance);
  }

  return 0;
}

double CalcPace(int time, double distance) {
  int pace;
  int hours;
  int minutes;
  int seconds;

  printf("\nEnter your total time (hh:mm:ss): ");
  scanf("%d:%d:%d", &hours, &minutes, &seconds);

  printf("Enter your total distance in miles: ");
  scanf("%lf", &distance);

  time = (hours * 3600) + (minutes * 60) + seconds;
  pace = (double) time / (double) distance;
  return pace;
}

int CalcTime(int pace, double distance) {
  int time;
  int minutes;
  int seconds;

  printf("\nEnter your pace in minutes per mile (mm:ss): ");
  scanf("%d:%d", &minutes, &seconds);

  printf("Enter your total distance in miles: ");
  scanf("%lf", &distance);

  pace = (60 * minutes) + seconds;

  time = pace * distance;
  return time;
}

double CalcDistance(int pace, int time) {
  double distance;
  int paceMinutes;
  int paceSeconds;
  int hours;
  int minutes;
  int seconds;

  printf("\nEnter your pace in minutes per mile (mm:ss): ");
  scanf("%d:%d", &paceMinutes, &paceSeconds);

  printf("Enter your total time (hh:mm:ss): ");
  scanf("%d:%d:%d", &hours, &minutes, &seconds);

  pace = (paceMinutes * 60) + paceSeconds;
  time = (hours * 3600) + (minutes * 60) + seconds;

  distance = (double) time / (double) pace;
  return distance;
}