#include <stdio.h>
#include <math.h>

// prototypes
int ConvertBase(int num, int numBase, int outputBase);
int CountDigits(int num);
int OutputDigits(int num, int outputBase);

int main(void) {
  int num;
  int numBase;
  int outputBase;

  // Asks for input
  printf("Enter a number: ");
  scanf("%d", &num);

  printf("Enter the base that is is in (2-10): ");
  scanf("%d", &numBase);

  printf("Enter the base that you would like to go to (2-10): ");
  scanf("%d", &outputBase);

  // Outputs number after base conversion
  printf("The number %d (base %d) in base %d is %d", num, numBase, outputBase, ConvertBase(num, numBase, outputBase));
  return 0;
}

// converts given number into base 10
int ConvertBase(int num, int numBase, int outputBase) {
  int baseTenSum = 0;
  int digit;
  int extra = 0;

  for (int i = 1; i <= CountDigits(num); i++) {
    digit = (num % (int) pow(10, i)) / (int) pow(10, i-1);
    baseTenSum += digit * (int) pow(numBase, i-1);
  }

  // converts base 10 number into desired base
  num = 0;
  int divisor = outputBase;
  int outputDigits = OutputDigits(baseTenSum, outputBase);

  // determines what the base 10 sum needs to be divided by to start
  for(int j = 1; baseTenSum / divisor >= outputBase; j++) {
    divisor = pow(outputBase, j);
  }

  for(int i = 0; (double) baseTenSum / (double) outputBase > 1; i++) {
    num += (baseTenSum / divisor) * pow(10, outputDigits - i - 1);
    baseTenSum %= divisor;
    divisor /= outputBase;
  }
  num += baseTenSum;

  return num;
}

// counts the number of digits in an int
int CountDigits(int num) {
  int counter = 0;
  while(num != 0) {
    num = num / 10;
    counter++;
  }
  return counter;
}

// counts the number of digits that will be needed for the output
int OutputDigits(int num, int outputBase) {
  int i = 0;
  while(num / (int) pow(outputBase, i) > 0) {
    i++;
  }
  return i;
}